from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    ld = LaunchDescription()

    pub_node = Node(
        package="sensor_dashboard",
        executable="sensor_pub",
        output="screen"
    )
    vis_node = Node(
        package="sensor_dashboard",
        executable="sensor_marker",
        output="screen"
    )
    srv_node = Node(
        package="sensor_dashboard",
        executable="sensor_reset_srv",
        output="screen"
    )
    monitor_node = Node(
        package="sensor_dashboard",
        executable="battery_monitor",
        output="screen"
    )

    ld.add_action(pub_node)
    ld.add_action(vis_node)
    ld.add_action(srv_node)
    ld.add_action(monitor_node)
    return ld
