import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import random

class SensorPublisher(Node):
    def __init__(self):
        super().__init__('sensor_publisher')
        self.temp_data = 25.0
        self.batt_data = 70.0
        self.pub_temp = self.create_publisher(Float32, '/temperature', 10)
        self.pub_batt = self.create_publisher(Float32, '/battery', 10)
        self.pub_temp_warn = self.create_publisher(Float32, '/temperature_warning', 10)
        self.timer = self.create_timer(1.0, self.publish_data)

    def publish_data(self):
        self.temp_data = round(random.uniform(15.0, 35.0), 1)
        self.batt_data = round(random.uniform(0.0, 100.0), 1)

        temp_msg = Float32()
        temp_msg.data = self.temp_data
        self.pub_temp.publish(temp_msg)

        batt_msg = Float32()
        batt_msg.data = self.batt_data
        self.pub_batt.publish(batt_msg)

        if self.temp_data > 30.0:
            self.pub_temp_warn.publish(temp_msg)
            self.get_logger().warn(f"温度过高告警：{self.temp_data}℃")

        self.get_logger().info(f"温度:{self.temp_data}℃ | 电量:{self.batt_data}%")

    def reset_data(self):
        self.temp_data = 25.0
        self.batt_data = 70.0
        self.get_logger().info("传感器数据已重置为初始值")

def main():
    rclpy.init()
    node = SensorPublisher()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
