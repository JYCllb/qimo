import rclpy
from rclpy.node import Node
from std_srvs.srv import Trigger
from sensor_dashboard.sensor_publisher import SensorPublisher

class SensorResetService(Node):
    def __init__(self):
        super().__init__('sensor_reset_service')
        self.sensor_node = SensorPublisher()
        self.srv = self.create_service(Trigger, '/sensor_reset', self.reset_callback)

    def reset_callback(self, req, resp):
        self.sensor_node.reset_data()
        resp.success = True
        resp.message = "传感器数据重置完成"
        return resp

def main():
    rclpy.init()
    node = SensorResetService()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
