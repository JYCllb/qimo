import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from visualization_msgs.msg import Marker, MarkerArray

class SensorMarkerVis(Node):
    def __init__(self):
        super().__init__('sensor_marker_vis')
        self.sub_temp = self.create_subscription(Float32, '/temperature', self.temp_callback, 10)
        self.sub_batt = self.create_subscription(Float32, '/battery', self.batt_callback, 10)
        self.marker_pub = self.create_publisher(MarkerArray, '/sensor_markers', 10)
        self.temp = 25.0
        self.batt = 70.0
        self.timer = self.create_timer(0.1, self.render_marker)

    def temp_callback(self, msg):
        self.temp = msg.data
    def batt_callback(self, msg):
        self.batt = msg.data

    def render_marker(self):
        marker_array = MarkerArray()
        stamp = self.get_clock().now().to_msg()

        # 温度方块
        temp_box = Marker()
        temp_box.header.frame_id = "map"
        temp_box.header.stamp = stamp
        temp_box.id = 0
        temp_box.type = Marker.CUBE
        temp_box.action = Marker.ADD
        temp_box.pose.position.x = -1.0
        temp_box.pose.position.y = 0.0
        temp_box.pose.position.z = 0.25
        temp_box.scale.x = 0.5
        temp_box.scale.y = 0.5
        temp_box.scale.z = 0.5
        if self.temp > 30.0:
            temp_box.color.r, temp_box.color.g, temp_box.color.b = 1.0, 0.0, 0.0
        else:
            temp_box.color.r, temp_box.color.g, temp_box.color.b = 0.0, 0.0, 1.0
        temp_box.color.a = 0.7
        marker_array.markers.append(temp_box)

        # 温度文字
        temp_text = Marker()
        temp_text.header.frame_id = "map"
        temp_text.header.stamp = stamp
        temp_text.id = 1
        temp_text.type = Marker.TEXT_VIEW_FACING
        temp_text.action = Marker.ADD
        temp_text.pose.position.x = -1.0
        temp_text.pose.position.y = 0.0
        temp_text.pose.position.z = 1.0
        temp_text.scale.z = 0.3
        temp_text.color.r = temp_text.color.g = temp_text.color.b = 1.0
        temp_text.color.a = 1.0
        temp_text.text = f"Temp: {self.temp:.1f} ℃"
        marker_array.markers.append(temp_text)

        # 电池圆柱
        batt_cyl = Marker()
        batt_cyl.header.frame_id = "map"
        batt_cyl.header.stamp = stamp
        batt_cyl.id = 2
        batt_cyl.type = Marker.CYLINDER
        batt_cyl.action = Marker.ADD
        batt_cyl.pose.position.x = 1.0
        batt_cyl.pose.position.y = 0.0
        batt_cyl.pose.position.z = 0.05
        batt_cyl.scale.x = 0.6
        batt_cyl.scale.y = 0.6
        batt_cyl.scale.z = self.batt / 100.0 * 0.3
        if self.batt < 20.0:
            batt_cyl.color.r, batt_cyl.color.g, batt_cyl.color.b = 1.0, 0.0, 0.0
        else:
            batt_cyl.color.r, batt_cyl.color.g, batt_cyl.color.b = 0.0, 1.0, 0.0
        batt_cyl.color.a = 0.7
        marker_array.markers.append(batt_cyl)

        # 电池文字
        batt_text = Marker()
        batt_text.header.frame_id = "map"
        batt_text.header.stamp = stamp
        batt_text.id = 3
        batt_text.type = Marker.TEXT_VIEW_FACING
        batt_text.action = Marker.ADD
        batt_text.pose.position.x = 1.0
        batt_text.pose.position.y = 0.0
        batt_text.pose.position.z = 1.0
        batt_text.scale.z = 0.3
        batt_text.color.r = batt_text.color.g = batt_text.color.b = 1.0
        batt_text.color.a = 1.0
        batt_text.text = f"Battery: {self.batt:.1f} %"
        marker_array.markers.append(batt_text)

        self.marker_pub.publish(marker_array)

def main():
    rclpy.init()
    node = SensorMarkerVis()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
