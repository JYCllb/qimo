import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32

class BatteryWarnMonitor(Node):
    def __init__(self):
        super().__init__('battery_warn_monitor')
        self.sub_battery = self.create_subscription(Float32, '/battery', self.battery_callback, 10)

    def battery_callback(self, msg):
        battery_value = msg.data
        if battery_value < 20.0:
            self.get_logger().error(f"Low Battery! 当前电量: {battery_value}%")

def main():
    rclpy.init()
    node = BatteryWarnMonitor()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
