from setuptools import setup
import os
from glob import glob

package_name = 'sensor_dashboard'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py'))
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='abc',
    maintainer_email='abc@todo.com',
    description='Rviz2 传感器仪表盘',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'sensor_pub = sensor_dashboard.sensor_publisher:main',
            'sensor_marker = sensor_dashboard.sensor_marker_vis:main',
            'sensor_reset_srv = sensor_dashboard.sensor_reset_service:main',
            'battery_monitor = sensor_dashboard.battery_warn_monitor:main',
        ],
    },
)
